function getSuggestion() {
    const suggestions = [
        "Try a Python basics module today!",
        "Explore Machine Learning fundamentals.",
        "Revise JavaScript functions and DOM.",
        "Practice Data Structures in Java.",
        "Watch a 10-minute video on AI ethics."
    ];
    const suggestion = suggestions[Math.floor(Math.random() * suggestions.length)];
    document.getElementById('suggestion').innerText = suggestion;
}

# EduMentor

EduMentor is an AI-powered personalized learning platform built for HackOn.

## 🚀 Features

- Personalized learning suggestions
- Beginner-friendly UI
- Ready for AI integration

## 🛠 Tech Stack

- HTML, CSS, JavaScript
- Ready for backend and AI enhancements

## 📌 Purpose

To guide learners with AI-generated, customized content based on their learning patterns and goals.

## 🔮 Scope

Future upgrades will include:
- AI-based recommendation engine
- User authentication and progress tracking
- Backend with Node.js or Python (Flask)

Made with ❤️ for HackOn 2025.
